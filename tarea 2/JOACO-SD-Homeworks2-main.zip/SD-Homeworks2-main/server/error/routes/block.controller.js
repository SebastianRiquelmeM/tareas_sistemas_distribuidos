const { poolGRPC } = require('../configs/database')
const axios = require('axios')
const https = require('https')

const getBlock = async (req, res) => {
    
  };


module.exports = {
    getBlock
};