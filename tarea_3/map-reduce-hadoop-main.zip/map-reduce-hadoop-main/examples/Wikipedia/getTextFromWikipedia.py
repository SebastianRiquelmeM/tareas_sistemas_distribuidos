import wikipedia as wiki

a = wiki.page("Inquisición")

print(a.content)